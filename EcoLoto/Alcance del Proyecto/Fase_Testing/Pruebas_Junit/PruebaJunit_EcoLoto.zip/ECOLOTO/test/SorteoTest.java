
import ecoloto.Bolsa;
import ecoloto.Sorteo;
import java.util.Arrays;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SorteoTest {

    @Test
    public void testBolsaBienReciclada() {
        // Creo un objeto Sorteo
        Sorteo s = new Sorteo();
         // Creo una bolsa nueva
        Bolsa bolsa = new Bolsa();
        bolsa.agregarResiduo("plastico");//añado un residuo por lo que esta bien reciclado

        bolsa.mostrarContenido();//imprime por consola, no afecta al test
         //llamada al metodo para validar y devuelve el bote actual
        double resultado = s.procesarBolsa(bolsa);
//comprobacion de que el resultado es de 1000 euros,ya que la bolsa esta bien reciclada
        assertEquals(1000.0, resultado, 0.0);
    }

    @Test
    public void testBolsaMalReciclada() {

        Sorteo s = new Sorteo();

        Bolsa bolsa = new Bolsa();
        bolsa.agregarResiduo("plastico");
        bolsa.agregarResiduo("vidrio");

        bolsa.mostrarContenido();

        double resultado = s.procesarBolsa(bolsa);
  //comprobación de que el bote es de 2000 euros ya que esta mal reciclada la bolsa
        assertEquals(2000.0, resultado, 0.0);
    }

    @Test
    public void testAcumulacion() {
//obj sorteo
        Sorteo s = new Sorteo();
//bolsa bien reciclada
        Bolsa b1 = new Bolsa();
        b1.agregarResiduo("plastico");
//bolsa mal reciclada
        Bolsa b2 = new Bolsa();
        b2.agregarResiduo("plastico");
        b2.agregarResiduo("vidrio");

        s.procesarBolsa(b1); // semana 1 con bolsa 1
        double resultado = s.procesarBolsa(b2); // semana 2 con bolda 2
          //bote final es de 2000
        assertEquals(2000.0, resultado, 0.0);
    }
}
