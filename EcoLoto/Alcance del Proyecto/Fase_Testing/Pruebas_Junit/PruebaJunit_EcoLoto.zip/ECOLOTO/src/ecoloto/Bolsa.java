
package ecoloto;

import java.util.ArrayList;
import java.util.List;


public class Bolsa {

    private List<String> residuos;

    public Bolsa() {
        this.residuos = new ArrayList<>();
    }

    public void agregarResiduo(String residuo) {
        residuos.add(residuo);
    }

    public List<String> getResiduos() {
        return residuos;
    }

    public boolean estaMalReciclada() {
        return residuos.size() > 1;
    }

    public void mostrarContenido() {
        System.out.println("Contenido de la bolsa: " + residuos);
    }
}
