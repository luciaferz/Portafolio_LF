package ecoloto;

import java.util.Scanner;

/**
 * logica del programa
 *///guarda el resultado antes de devolver
//si el reciclaje es correcto devuelve el nuevo bote y llama al metodo entregar premio,sino el nuevo bote sera el actual+1000
//recibe 2 datos(reciclajeCorrecto y boteactual) y devuelve el valor del bote
public class Sorteo {

    private double bote = 1000.0;
    private int semana = 1;
    private Scanner scanner = new Scanner(System.in);

    public void iniciar() {

        boolean hayGanador = false;

        while (!hayGanador) {

            System.out.println("SEMANA " + semana);
            System.out.println("Bote actual: " + bote);

            Bolsa bolsa = crearBolsa();

            System.out.println("Analizando bolsa:");

            bolsa.mostrarContenido();

            if (!bolsa.estaMalReciclada()) {

                System.out.println("Hay ganador!,el premio es de: " + bote + " euros");
                System.out.println("Bote actual : " + 1000.0);

                bote = 1000.0;
                hayGanador = true;

            } else {

                System.out.println("Bolsa mal reciclada");
                bote += 1000.0;
                semana++;
            }
        }
    }

    private Bolsa crearBolsa() {

        Bolsa bolsa = new Bolsa();

        System.out.println("Introduce residuos separados por coma:");
        String input = scanner.nextLine();

        String[] residuos = input.split(",");

        for (String r : residuos) {
            bolsa.agregarResiduo(r.trim());
        }

        return bolsa;
    }

    public double procesarBolsa(Bolsa bolsa) {

        if (!bolsa.estaMalReciclada()) {
            bote = 1000.0;
        } else {
            bote += 1000.0;
        }

        return bote;
    }

    public double getBote() {
        return bote;
    }
}
