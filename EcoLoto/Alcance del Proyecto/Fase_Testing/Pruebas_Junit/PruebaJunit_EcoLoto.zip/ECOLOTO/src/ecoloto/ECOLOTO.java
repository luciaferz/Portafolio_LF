package ecoloto;

import java.util.Arrays;

public class ECOLOTO {

    public static void main(String[] args) {
//objeto de sorteo
        Sorteo sorteo = new Sorteo();
        sorteo.iniciar();
    }
}
    

